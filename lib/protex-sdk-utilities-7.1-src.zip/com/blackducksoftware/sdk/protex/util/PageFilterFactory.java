/*
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */
package com.blackducksoftware.sdk.protex.util;

import java.util.Arrays;

import com.blackducksoftware.sdk.protex.common.ComponentColumn;
import com.blackducksoftware.sdk.protex.common.ComponentPageFilter;
import com.blackducksoftware.sdk.protex.common.ComponentType;
import com.blackducksoftware.sdk.protex.common.FileDiscoveryPatternColumn;
import com.blackducksoftware.sdk.protex.common.FileDiscoveryPatternPageFilter;
import com.blackducksoftware.sdk.protex.common.LearnedIdentificationColumn;
import com.blackducksoftware.sdk.protex.common.LearnedIdentificationPageFilter;
import com.blackducksoftware.sdk.protex.common.PageFilter;
import com.blackducksoftware.sdk.protex.common.SortType;
import com.blackducksoftware.sdk.protex.license.LicenseInfoColumn;
import com.blackducksoftware.sdk.protex.license.LicenseInfoPageFilter;
import com.blackducksoftware.sdk.protex.obligation.AssignedObligationColumn;
import com.blackducksoftware.sdk.protex.obligation.AssignedObligationPageFilter;
import com.blackducksoftware.sdk.protex.project.ProjectColumn;
import com.blackducksoftware.sdk.protex.project.ProjectInfoColumn;
import com.blackducksoftware.sdk.protex.project.ProjectInfoPageFilter;
import com.blackducksoftware.sdk.protex.project.ProjectPageFilter;
import com.blackducksoftware.sdk.protex.project.localcomponent.LocalComponentColumn;
import com.blackducksoftware.sdk.protex.project.localcomponent.LocalComponentPageFilter;
import com.blackducksoftware.sdk.protex.project.template.TemplateInfoColumn;
import com.blackducksoftware.sdk.protex.project.template.TemplateInfoPageFilter;
import com.blackducksoftware.sdk.protex.role.UserRoleInfoColumn;
import com.blackducksoftware.sdk.protex.role.UserRoleInfoPageFilter;
import com.blackducksoftware.sdk.protex.user.UserColumn;
import com.blackducksoftware.sdk.protex.user.UserPageFilter;

/**
 * Convenience class to create and manage PageFilter objects
 *
 * PageFitler objects can be used to force particular Sort orders as well as to limit the number of objects returned.
 * The main purpose of limiting the number of returned objects is performance and memory management on the client side
 * as well as on the server side.
 *
 */
public class PageFilterFactory {

    public static ProjectPageFilter getAllRows(ProjectColumn sortColumn) {
        ProjectPageFilter pageFilter = getAllRows(new ProjectPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static ProjectInfoPageFilter getAllRows(ProjectInfoColumn sortColumn) {
        ProjectInfoPageFilter pageFilter = getAllRows(new ProjectInfoPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static TemplateInfoPageFilter getAllRows(TemplateInfoColumn sortColumn) {
        TemplateInfoPageFilter pageFilter = getAllRows(new TemplateInfoPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static LocalComponentPageFilter getAllRows(LocalComponentColumn sortColumn) {
        LocalComponentPageFilter pageFilter = getAllRows(new LocalComponentPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static LicenseInfoPageFilter getAllRows(LicenseInfoColumn sortColumn) {
        LicenseInfoPageFilter pageFilter = getAllRows(new LicenseInfoPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static ComponentPageFilter getAllRows(ComponentColumn sortColumn) {
        ComponentPageFilter pageFilter = getAllRows(new ComponentPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        pageFilter.setIncludeDeprecated(false);
        pageFilter.getComponentTypes().addAll(Arrays.asList(ComponentType.values()));
        return pageFilter;
    }

    public static AssignedObligationPageFilter getAllRows(AssignedObligationColumn sortColumn) {
        AssignedObligationPageFilter pageFilter = getAllRows(new AssignedObligationPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static LearnedIdentificationPageFilter getAllRows(LearnedIdentificationColumn sortColumn) {
        LearnedIdentificationPageFilter pageFilter = getAllRows(new LearnedIdentificationPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static FileDiscoveryPatternPageFilter getAllRows(FileDiscoveryPatternColumn sortColumn) {
        return getAllRows(sortColumn, SortType.ALPHABETICAL_CASE_INSENSITIVE);
    }

    public static UserPageFilter getAllRows(UserColumn sortColumn) {
        UserPageFilter pageFilter = getAllRows(new UserPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static UserRoleInfoPageFilter getAllRows(UserRoleInfoColumn sortColumn) {
        UserRoleInfoPageFilter pageFilter = getAllRows(new UserRoleInfoPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static FileDiscoveryPatternPageFilter getAllRows(FileDiscoveryPatternColumn sortColumn,
            SortType sortType) {
        FileDiscoveryPatternPageFilter pageFilter = getAllRows(new FileDiscoveryPatternPageFilter(), sortType);
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static UserPageFilter getAllRows(UserColumn sortColumn, SortType sortType) {
        UserPageFilter pageFilter = getAllRows(new UserPageFilter(), sortType);
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static ComponentPageFilter getFirstPage(int pageSize, ComponentColumn sortedColumn, boolean sortAssending) {
        ComponentPageFilter firstPage = getFirstPage(new ComponentPageFilter(), pageSize, sortAssending);
        firstPage.setSortedColumn(sortedColumn);
        firstPage.setIncludeDeprecated(false);
        firstPage.getComponentTypes().addAll(Arrays.asList(ComponentType.values()));
        return firstPage;
    }

    public static LicenseInfoPageFilter getFirstPage(int pageSize, LicenseInfoColumn sortedColumn, boolean sortAssending) {
        LicenseInfoPageFilter firstPage = getFirstPage(new LicenseInfoPageFilter(), pageSize,
                sortAssending);
        firstPage.setSortedColumn(sortedColumn);
        return firstPage;
    }

    public static <T extends PageFilter> T getNextPage(T pageFilter) {
        int pageSize = 1;
        if (pageFilter.getFirstRowIndex() == 0) {
            pageSize = Math.max(1, pageFilter.getLastRowIndex() - pageFilter.getFirstRowIndex());
        } else {
            pageSize = Math.max(1, pageFilter.getLastRowIndex() - pageFilter.getFirstRowIndex() + 1);
        }
        pageFilter.setFirstRowIndex(pageFilter.getLastRowIndex() + 1);
        pageFilter.setLastRowIndex(pageFilter.getFirstRowIndex() + pageSize - 1);

        return pageFilter;
    }

    private static <T extends PageFilter> T getAllRows(T pageFilter) {
        return getAllRows(pageFilter, SortType.ALPHABETICAL_CASE_INSENSITIVE);
    }

    private static <T extends PageFilter> T getAllRows(T pageFilter, SortType sortType) {
        pageFilter.setFirstRowIndex(0);
        pageFilter.setLastRowIndex(Integer.MAX_VALUE);
        pageFilter.setSortAscending(Boolean.TRUE);
        pageFilter.setSortType(sortType);
        return pageFilter;
    }

    private static <T extends PageFilter> T getFirstPage(T firstPage, int pageSize, boolean sortAssending) {
        firstPage.setFirstRowIndex(1);
        firstPage.setLastRowIndex(pageSize);
        firstPage.setSortAscending(sortAssending);
        firstPage.setSortType(SortType.ALPHABETICAL_CASE_INSENSITIVE);
        return firstPage;
    }

}
