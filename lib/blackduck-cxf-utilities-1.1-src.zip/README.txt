This folder/jar contains some universal CXF Logging Interceptors to do secure logging and/or pretty printing of messages.

These interceptors should work with cxf 2.0 and are definitely tested with cxf 2.2.7

It's sources live in a source jar and also in the protex.sdkclient project in a non src folder (where it has been originally created).

This package is used (distributed) through the library project as binary jar, as it is expected to be stable and transcends products (protex, export, code center)
