package com.blackducksoftware.sdk.impl.logging;

/**
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/ All rights reserved.
 * 
 * This software is the confidential and proprietary information of Black Duck
 * Software ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Black Duck Software.
 */

public class LoggingMessageStripWsse extends LoggingMessageSecure {
	public LoggingMessageStripWsse(String h, String i) {
		super(h, i);
	}

	private static final String WSSE_SECURITY_HEADER_BEGIN_TAG = "<wsse:Security";

	private static final char END_OF_TAG = '>';

	private static final char EMPTY_TAG = '/';

	private static final String WSSE_SECURITY_HEADER_END_TAG = "</wsse:Security>";

	@Override
	protected StringBuilder formatPayload(StringBuilder builder) {
		return filterWsseSecurity(getPayload());
	}

	private StringBuilder filterWsseSecurity(StringBuilder builder) {
		int startWsse = builder.indexOf(WSSE_SECURITY_HEADER_BEGIN_TAG);
		if (startWsse > 0) {
			int startHeader = startWsse
					+ WSSE_SECURITY_HEADER_BEGIN_TAG.length() - 1;
			boolean emptyHeader = false;
			while (++startHeader < builder.length()) {
				if (builder.charAt(startHeader) == END_OF_TAG) {
					if (builder.charAt(startHeader - 1) == EMPTY_TAG) {
						emptyHeader = true;
					}
					break;
				}
			}
//			 System.out.println("Password: " + (emptyHeader ? "<empty>" :builder.substring(startHeader, startHeader + 10)));
			if (!emptyHeader) {
				int endHeader = builder.indexOf(WSSE_SECURITY_HEADER_END_TAG,
						startHeader);
//				 System.out.println("Password: " + builder.substring(startHeader + 1, endHeader));
				return builder.replace(startHeader + 1, endHeader, "...");
			}
		}
		return builder;
	}

//     public static void main(String[] args) {
//    	 LoggingMessageStripWsse me = new LoggingMessageStripWsse("::::", "????");
//     StringBuilder payload = new StringBuilder().append("<fdaf><wsse:Security><wsse:Password>My Secret</wsse:Password></wsse:Security></fdaf>");
//     StringBuilder masked = me.formatPayload(new StringBuilder(payload));
//     System.out.println(payload + " ==> " + masked);
//     payload = new StringBuilder().append("<fdaf><wsse:Security attr=\"jljlkjk\"><wsse:Password attr=\"dafds\">My Secret</wsse:Password></wsse:Security></fdaf>");
//     masked = me.formatPayload(new StringBuilder(payload));
//     System.out.println(payload + " ==> " + masked);
//     payload = new StringBuilder().append("<fdaf><wsse:Security/></fdaf>");
//     masked = me.formatPayload(new StringBuilder(payload));
//     System.out.println(payload + " ==> " + masked);
//     payload = new StringBuilder().append("<fdaf><wsse:Security attr=\"jljlkjk\"/></fdaf>");
//     masked = me.formatPayload(new StringBuilder(payload));
//     System.out.println(payload + " ==> " + masked);
//     }

}
