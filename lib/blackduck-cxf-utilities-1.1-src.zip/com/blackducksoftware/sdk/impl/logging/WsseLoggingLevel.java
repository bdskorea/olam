package com.blackducksoftware.sdk.impl.logging;

/**
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */
public enum WsseLoggingLevel {
    /**
     * wsse-stripped & pretty print
     */

    COMPACT_PRETTY("0"),

    /**
     * wsse-stripped, standard print
     */
    COMPACT("1"),

    /**
     * include wsse and standard print, but password masked
     */
    VERBOSE_SECURE("2"),

    /**
     * include all in pretty print & mask password
     */
    VERBOSE_SECURE_PRETTY("3"),

    /**
     * include all in standard print and don't mask the password
     */
    VERBOSE("4")

    ;

    private String externalLevel = null;

    public String getExternalLevel() {
        return externalLevel;
    }

    private WsseLoggingLevel(String externalLevel) {
        this.externalLevel = externalLevel;
    }

    /**
     * Create an Enum object from an external representation, such as an option value for a command line.
     * 
     * @param externalLevel
     *            The external option value
     * @return The WsseLogginLeve enum
     * 
     * @throws RuntimeException
     *             if external level value is undefined.
     */
    public static WsseLoggingLevel createFromExternalLevel(String externalLevel) {
        for (WsseLoggingLevel level : values()) {
            if (externalLevel.equals(level.getExternalLevel())) { return level; }
        }
        throw new RuntimeException("No Value defined for external Level '" + externalLevel + "'");
    }

}
