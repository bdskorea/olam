package com.blackducksoftware.sdk.impl.logging;

import java.util.logging.Logger;

import org.apache.cxf.common.logging.LogUtils;

/**
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */

/**
 * 
 */
public class WSSEPasswordMaskedLoggingOutInterceptor extends AbstractPayloadFilteredLoggingOutInterceptor {
    private static final Logger LOG = LogUtils.getL7dLogger(WSSEPasswordMaskedLoggingOutInterceptor.class);

    @Override
    Logger getLogger() {
        return LOG;
    }

    @Override
    LoggingMessageSecure createNewLoggingMessage(String id) {
        return new LoggingMessagePasswordMasked(" >>> ", id);
    }
}
