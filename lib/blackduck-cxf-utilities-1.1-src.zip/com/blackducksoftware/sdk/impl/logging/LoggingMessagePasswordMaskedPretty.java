package com.blackducksoftware.sdk.impl.logging;

/*
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */

public class LoggingMessagePasswordMaskedPretty extends LoggingMessagePasswordMasked {

    public LoggingMessagePasswordMaskedPretty(String h, String i) {
        super(h, i);
    }

    @Override
    protected StringBuilder formatPayload(StringBuilder builder) {
        return new StringBuilder(new XmlFormatter().prettyPrint(super.formatPayload(getPayload()).toString()));
    }

}
