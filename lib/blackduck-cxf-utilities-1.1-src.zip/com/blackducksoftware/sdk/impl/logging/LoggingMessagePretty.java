package com.blackducksoftware.sdk.impl.logging;

import org.xml.sax.SAXParseException;

/**
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */

public class LoggingMessagePretty extends LoggingMessageSecure {
    public LoggingMessagePretty(String h, String i) {
        super(h, i);
    }

    @Override
    protected StringBuilder formatPayload(StringBuilder builder) {
    	try {
    		return new StringBuilder(new XmlFormatter().prettyPrint(getPayload().toString()));
    	} catch (RuntimeException e) {
    		// PROTEX-9322:  If we get a parse error while trying to format the payload as XML,
    		// simply return the payload unformatted.
    		if ((e.getCause() != null) && (e.getCause() instanceof SAXParseException)) {
    			return getPayload();
    		} else {
    			throw e;
    		}
    	}
    }

}
