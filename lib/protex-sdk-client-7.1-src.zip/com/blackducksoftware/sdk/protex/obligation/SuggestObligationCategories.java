
package com.blackducksoftware.sdk.protex.obligation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for suggestObligationCategories complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="suggestObligationCategories">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="anyWordStartsWith" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "suggestObligationCategories", propOrder = {
    "anyWordStartsWith"
})
public class SuggestObligationCategories {

    protected String anyWordStartsWith;

    /**
     * Gets the value of the anyWordStartsWith property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnyWordStartsWith() {
        return anyWordStartsWith;
    }

    /**
     * Sets the value of the anyWordStartsWith property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnyWordStartsWith(String value) {
        this.anyWordStartsWith = value;
    }

}
