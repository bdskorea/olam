
package com.blackducksoftware.sdk.protex.obligation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for suggestObligations complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="suggestObligations">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="anyWordStartsWith" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="arg1" type="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}obligationPageFilter" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "suggestObligations", propOrder = {
    "anyWordStartsWith",
    "arg1"
})
public class SuggestObligations {

    protected String anyWordStartsWith;
    protected ObligationPageFilter arg1;

    /**
     * Gets the value of the anyWordStartsWith property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnyWordStartsWith() {
        return anyWordStartsWith;
    }

    /**
     * Sets the value of the anyWordStartsWith property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnyWordStartsWith(String value) {
        this.anyWordStartsWith = value;
    }

    /**
     * Gets the value of the arg1 property.
     * 
     * @return
     *     possible object is
     *     {@link ObligationPageFilter }
     *     
     */
    public ObligationPageFilter getArg1() {
        return arg1;
    }

    /**
     * Sets the value of the arg1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObligationPageFilter }
     *     
     */
    public void setArg1(ObligationPageFilter value) {
        this.arg1 = value;
    }

}
