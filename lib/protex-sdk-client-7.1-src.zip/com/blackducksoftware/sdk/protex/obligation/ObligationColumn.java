
package com.blackducksoftware.sdk.protex.obligation;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for obligationColumn.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="obligationColumn">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="OBLIGATION_ID"/>
 *     &lt;enumeration value="OBLIGATION_LABEL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "obligationColumn")
@XmlEnum
public enum ObligationColumn {

    OBLIGATION_ID,
    OBLIGATION_LABEL;

    public String value() {
        return name();
    }

    public static ObligationColumn fromValue(String v) {
        return valueOf(v);
    }

}
