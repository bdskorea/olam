
package com.blackducksoftware.sdk.protex.obligation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for assignedObligationRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="assignedObligationRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}obligationRequest">
 *       &lt;sequence>
 *         &lt;element name="fulfilled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="reviewAndReport" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "assignedObligationRequest", propOrder = {
    "fulfilled",
    "reviewAndReport"
})
@XmlSeeAlso({
    AssignedObligation.class
})
public class AssignedObligationRequest
    extends ObligationRequest
{

    protected Boolean fulfilled;
    protected Boolean reviewAndReport;

    /**
     * Gets the value of the fulfilled property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFulfilled() {
        return fulfilled;
    }

    /**
     * Sets the value of the fulfilled property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFulfilled(Boolean value) {
        this.fulfilled = value;
    }

    /**
     * Gets the value of the reviewAndReport property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReviewAndReport() {
        return reviewAndReport;
    }

    /**
     * Sets the value of the reviewAndReport property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReviewAndReport(Boolean value) {
        this.reviewAndReport = value;
    }

}
