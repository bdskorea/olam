
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for updateAnonymousAccessPolicy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateAnonymousAccessPolicy">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="anonymousAccessAllowed" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateAnonymousAccessPolicy", propOrder = {
    "anonymousAccessAllowed"
})
public class UpdateAnonymousAccessPolicy {

    protected Boolean anonymousAccessAllowed;

    /**
     * Gets the value of the anonymousAccessAllowed property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAnonymousAccessAllowed() {
        return anonymousAccessAllowed;
    }

    /**
     * Sets the value of the anonymousAccessAllowed property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAnonymousAccessAllowed(Boolean value) {
        this.anonymousAccessAllowed = value;
    }

}
