
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for protexSystemInformation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="protexSystemInformation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="bdsBasicDatabaseVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsClientProtcolVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsClientVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsCustomDatabaseVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsEstimationToolProtocolVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsEstimationToolVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsKnowledgebaseUpdateLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsKnowledgebaseUpdateStream" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsProxyProtcolVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsProxyVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsRawFingerprintFilesVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsServerLibraryVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsSoapProtcolVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsSoapVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsToolProtcolVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsToolVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsUpdateProtcolVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bdsUpdateVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fingerprintBasicDatabaseVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fingerprintCustomDatabaseVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localRegistrationServiceVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="protexSdkVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="registrationServiceVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="serviceVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="soapServiceVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="updateServiceVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "protexSystemInformation", propOrder = {
    "bdsBasicDatabaseVersion",
    "bdsClientProtcolVersion",
    "bdsClientVersion",
    "bdsCustomDatabaseVersion",
    "bdsEstimationToolProtocolVersion",
    "bdsEstimationToolVersion",
    "bdsKnowledgebaseUpdateLevel",
    "bdsKnowledgebaseUpdateStream",
    "bdsProxyProtcolVersion",
    "bdsProxyVersion",
    "bdsRawFingerprintFilesVersion",
    "bdsServerLibraryVersion",
    "bdsSoapProtcolVersion",
    "bdsSoapVersion",
    "bdsToolProtcolVersion",
    "bdsToolVersion",
    "bdsUpdateProtcolVersion",
    "bdsUpdateVersion",
    "fingerprintBasicDatabaseVersion",
    "fingerprintCustomDatabaseVersion",
    "localRegistrationServiceVersion",
    "protexSdkVersion",
    "registrationServiceVersion",
    "serviceVersion",
    "soapServiceVersion",
    "updateServiceVersion"
})
public class ProtexSystemInformation {

    protected String bdsBasicDatabaseVersion;
    protected String bdsClientProtcolVersion;
    protected String bdsClientVersion;
    protected String bdsCustomDatabaseVersion;
    protected String bdsEstimationToolProtocolVersion;
    protected String bdsEstimationToolVersion;
    protected String bdsKnowledgebaseUpdateLevel;
    protected String bdsKnowledgebaseUpdateStream;
    protected String bdsProxyProtcolVersion;
    protected String bdsProxyVersion;
    protected String bdsRawFingerprintFilesVersion;
    protected String bdsServerLibraryVersion;
    protected String bdsSoapProtcolVersion;
    protected String bdsSoapVersion;
    protected String bdsToolProtcolVersion;
    protected String bdsToolVersion;
    protected String bdsUpdateProtcolVersion;
    protected String bdsUpdateVersion;
    protected String fingerprintBasicDatabaseVersion;
    protected String fingerprintCustomDatabaseVersion;
    protected String localRegistrationServiceVersion;
    protected String protexSdkVersion;
    protected String registrationServiceVersion;
    protected String serviceVersion;
    protected String soapServiceVersion;
    protected String updateServiceVersion;

    /**
     * Gets the value of the bdsBasicDatabaseVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsBasicDatabaseVersion() {
        return bdsBasicDatabaseVersion;
    }

    /**
     * Sets the value of the bdsBasicDatabaseVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsBasicDatabaseVersion(String value) {
        this.bdsBasicDatabaseVersion = value;
    }

    /**
     * Gets the value of the bdsClientProtcolVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsClientProtcolVersion() {
        return bdsClientProtcolVersion;
    }

    /**
     * Sets the value of the bdsClientProtcolVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsClientProtcolVersion(String value) {
        this.bdsClientProtcolVersion = value;
    }

    /**
     * Gets the value of the bdsClientVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsClientVersion() {
        return bdsClientVersion;
    }

    /**
     * Sets the value of the bdsClientVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsClientVersion(String value) {
        this.bdsClientVersion = value;
    }

    /**
     * Gets the value of the bdsCustomDatabaseVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsCustomDatabaseVersion() {
        return bdsCustomDatabaseVersion;
    }

    /**
     * Sets the value of the bdsCustomDatabaseVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsCustomDatabaseVersion(String value) {
        this.bdsCustomDatabaseVersion = value;
    }

    /**
     * Gets the value of the bdsEstimationToolProtocolVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsEstimationToolProtocolVersion() {
        return bdsEstimationToolProtocolVersion;
    }

    /**
     * Sets the value of the bdsEstimationToolProtocolVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsEstimationToolProtocolVersion(String value) {
        this.bdsEstimationToolProtocolVersion = value;
    }

    /**
     * Gets the value of the bdsEstimationToolVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsEstimationToolVersion() {
        return bdsEstimationToolVersion;
    }

    /**
     * Sets the value of the bdsEstimationToolVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsEstimationToolVersion(String value) {
        this.bdsEstimationToolVersion = value;
    }

    /**
     * Gets the value of the bdsKnowledgebaseUpdateLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsKnowledgebaseUpdateLevel() {
        return bdsKnowledgebaseUpdateLevel;
    }

    /**
     * Sets the value of the bdsKnowledgebaseUpdateLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsKnowledgebaseUpdateLevel(String value) {
        this.bdsKnowledgebaseUpdateLevel = value;
    }

    /**
     * Gets the value of the bdsKnowledgebaseUpdateStream property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsKnowledgebaseUpdateStream() {
        return bdsKnowledgebaseUpdateStream;
    }

    /**
     * Sets the value of the bdsKnowledgebaseUpdateStream property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsKnowledgebaseUpdateStream(String value) {
        this.bdsKnowledgebaseUpdateStream = value;
    }

    /**
     * Gets the value of the bdsProxyProtcolVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsProxyProtcolVersion() {
        return bdsProxyProtcolVersion;
    }

    /**
     * Sets the value of the bdsProxyProtcolVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsProxyProtcolVersion(String value) {
        this.bdsProxyProtcolVersion = value;
    }

    /**
     * Gets the value of the bdsProxyVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsProxyVersion() {
        return bdsProxyVersion;
    }

    /**
     * Sets the value of the bdsProxyVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsProxyVersion(String value) {
        this.bdsProxyVersion = value;
    }

    /**
     * Gets the value of the bdsRawFingerprintFilesVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsRawFingerprintFilesVersion() {
        return bdsRawFingerprintFilesVersion;
    }

    /**
     * Sets the value of the bdsRawFingerprintFilesVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsRawFingerprintFilesVersion(String value) {
        this.bdsRawFingerprintFilesVersion = value;
    }

    /**
     * Gets the value of the bdsServerLibraryVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsServerLibraryVersion() {
        return bdsServerLibraryVersion;
    }

    /**
     * Sets the value of the bdsServerLibraryVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsServerLibraryVersion(String value) {
        this.bdsServerLibraryVersion = value;
    }

    /**
     * Gets the value of the bdsSoapProtcolVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsSoapProtcolVersion() {
        return bdsSoapProtcolVersion;
    }

    /**
     * Sets the value of the bdsSoapProtcolVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsSoapProtcolVersion(String value) {
        this.bdsSoapProtcolVersion = value;
    }

    /**
     * Gets the value of the bdsSoapVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsSoapVersion() {
        return bdsSoapVersion;
    }

    /**
     * Sets the value of the bdsSoapVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsSoapVersion(String value) {
        this.bdsSoapVersion = value;
    }

    /**
     * Gets the value of the bdsToolProtcolVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsToolProtcolVersion() {
        return bdsToolProtcolVersion;
    }

    /**
     * Sets the value of the bdsToolProtcolVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsToolProtcolVersion(String value) {
        this.bdsToolProtcolVersion = value;
    }

    /**
     * Gets the value of the bdsToolVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsToolVersion() {
        return bdsToolVersion;
    }

    /**
     * Sets the value of the bdsToolVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsToolVersion(String value) {
        this.bdsToolVersion = value;
    }

    /**
     * Gets the value of the bdsUpdateProtcolVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsUpdateProtcolVersion() {
        return bdsUpdateProtcolVersion;
    }

    /**
     * Sets the value of the bdsUpdateProtcolVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsUpdateProtcolVersion(String value) {
        this.bdsUpdateProtcolVersion = value;
    }

    /**
     * Gets the value of the bdsUpdateVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBdsUpdateVersion() {
        return bdsUpdateVersion;
    }

    /**
     * Sets the value of the bdsUpdateVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBdsUpdateVersion(String value) {
        this.bdsUpdateVersion = value;
    }

    /**
     * Gets the value of the fingerprintBasicDatabaseVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFingerprintBasicDatabaseVersion() {
        return fingerprintBasicDatabaseVersion;
    }

    /**
     * Sets the value of the fingerprintBasicDatabaseVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFingerprintBasicDatabaseVersion(String value) {
        this.fingerprintBasicDatabaseVersion = value;
    }

    /**
     * Gets the value of the fingerprintCustomDatabaseVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFingerprintCustomDatabaseVersion() {
        return fingerprintCustomDatabaseVersion;
    }

    /**
     * Sets the value of the fingerprintCustomDatabaseVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFingerprintCustomDatabaseVersion(String value) {
        this.fingerprintCustomDatabaseVersion = value;
    }

    /**
     * Gets the value of the localRegistrationServiceVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalRegistrationServiceVersion() {
        return localRegistrationServiceVersion;
    }

    /**
     * Sets the value of the localRegistrationServiceVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalRegistrationServiceVersion(String value) {
        this.localRegistrationServiceVersion = value;
    }

    /**
     * Gets the value of the protexSdkVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProtexSdkVersion() {
        return protexSdkVersion;
    }

    /**
     * Sets the value of the protexSdkVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProtexSdkVersion(String value) {
        this.protexSdkVersion = value;
    }

    /**
     * Gets the value of the registrationServiceVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegistrationServiceVersion() {
        return registrationServiceVersion;
    }

    /**
     * Sets the value of the registrationServiceVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegistrationServiceVersion(String value) {
        this.registrationServiceVersion = value;
    }

    /**
     * Gets the value of the serviceVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceVersion() {
        return serviceVersion;
    }

    /**
     * Sets the value of the serviceVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceVersion(String value) {
        this.serviceVersion = value;
    }

    /**
     * Gets the value of the soapServiceVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoapServiceVersion() {
        return soapServiceVersion;
    }

    /**
     * Sets the value of the soapServiceVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoapServiceVersion(String value) {
        this.soapServiceVersion = value;
    }

    /**
     * Gets the value of the updateServiceVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdateServiceVersion() {
        return updateServiceVersion;
    }

    /**
     * Sets the value of the updateServiceVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateServiceVersion(String value) {
        this.updateServiceVersion = value;
    }

}
