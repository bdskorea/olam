
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.FileDiscoveryPatternRequest;


/**
 * <p>Java class for createFileDiscoveryPattern complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createFileDiscoveryPattern">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="fileDiscoveryPatternRequest" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}fileDiscoveryPatternRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createFileDiscoveryPattern", propOrder = {
    "fileDiscoveryPatternRequest"
})
public class CreateFileDiscoveryPattern {

    protected FileDiscoveryPatternRequest fileDiscoveryPatternRequest;

    /**
     * Gets the value of the fileDiscoveryPatternRequest property.
     * 
     * @return
     *     possible object is
     *     {@link FileDiscoveryPatternRequest }
     *     
     */
    public FileDiscoveryPatternRequest getFileDiscoveryPatternRequest() {
        return fileDiscoveryPatternRequest;
    }

    /**
     * Sets the value of the fileDiscoveryPatternRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileDiscoveryPatternRequest }
     *     
     */
    public void setFileDiscoveryPatternRequest(FileDiscoveryPatternRequest value) {
        this.fileDiscoveryPatternRequest = value;
    }

}
