
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.AnalysisDatabaseOptions;


/**
 * <p>Java class for updateAnalysisDatabaseOptions complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateAnalysisDatabaseOptions">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="analysisDatabaseOptions" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}analysisDatabaseOptions" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateAnalysisDatabaseOptions", propOrder = {
    "analysisDatabaseOptions"
})
public class UpdateAnalysisDatabaseOptions {

    protected AnalysisDatabaseOptions analysisDatabaseOptions;

    /**
     * Gets the value of the analysisDatabaseOptions property.
     * 
     * @return
     *     possible object is
     *     {@link AnalysisDatabaseOptions }
     *     
     */
    public AnalysisDatabaseOptions getAnalysisDatabaseOptions() {
        return analysisDatabaseOptions;
    }

    /**
     * Sets the value of the analysisDatabaseOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnalysisDatabaseOptions }
     *     
     */
    public void setAnalysisDatabaseOptions(AnalysisDatabaseOptions value) {
        this.analysisDatabaseOptions = value;
    }

}
