
package com.blackducksoftware.sdk.protex.policy.externalid;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getObjectIdByExternalId complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getObjectIdByExternalId">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="externalNamespaceKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="externalObjectId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="objectType" type="{urn:protex.blackducksoftware.com:sdk:v7.0:externalid}protexObjectType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getObjectIdByExternalId", propOrder = {
    "externalNamespaceKey",
    "externalObjectId",
    "objectType"
})
public class GetObjectIdByExternalId {

    protected String externalNamespaceKey;
    protected String externalObjectId;
    protected ProtexObjectType objectType;

    /**
     * Gets the value of the externalNamespaceKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalNamespaceKey() {
        return externalNamespaceKey;
    }

    /**
     * Sets the value of the externalNamespaceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalNamespaceKey(String value) {
        this.externalNamespaceKey = value;
    }

    /**
     * Gets the value of the externalObjectId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalObjectId() {
        return externalObjectId;
    }

    /**
     * Sets the value of the externalObjectId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalObjectId(String value) {
        this.externalObjectId = value;
    }

    /**
     * Gets the value of the objectType property.
     * 
     * @return
     *     possible object is
     *     {@link ProtexObjectType }
     *     
     */
    public ProtexObjectType getObjectType() {
        return objectType;
    }

    /**
     * Sets the value of the objectType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtexObjectType }
     *     
     */
    public void setObjectType(ProtexObjectType value) {
        this.objectType = value;
    }

}
