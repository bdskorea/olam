
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.FileDiscoveryPatternRequest;


/**
 * <p>Java class for updateFileDiscoveryPattern complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateFileDiscoveryPattern">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="patternId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fileDiscoveryPattern" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}fileDiscoveryPatternRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateFileDiscoveryPattern", propOrder = {
    "patternId",
    "fileDiscoveryPattern"
})
public class UpdateFileDiscoveryPattern {

    protected String patternId;
    protected FileDiscoveryPatternRequest fileDiscoveryPattern;

    /**
     * Gets the value of the patternId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatternId() {
        return patternId;
    }

    /**
     * Sets the value of the patternId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatternId(String value) {
        this.patternId = value;
    }

    /**
     * Gets the value of the fileDiscoveryPattern property.
     * 
     * @return
     *     possible object is
     *     {@link FileDiscoveryPatternRequest }
     *     
     */
    public FileDiscoveryPatternRequest getFileDiscoveryPattern() {
        return fileDiscoveryPattern;
    }

    /**
     * Sets the value of the fileDiscoveryPattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileDiscoveryPatternRequest }
     *     
     */
    public void setFileDiscoveryPattern(FileDiscoveryPatternRequest value) {
        this.fileDiscoveryPattern = value;
    }

}
