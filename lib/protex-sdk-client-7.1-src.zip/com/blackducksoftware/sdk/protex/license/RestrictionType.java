
package com.blackducksoftware.sdk.protex.license;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for restrictionType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="restrictionType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="HAS_RESTRICTIONS"/>
 *     &lt;enumeration value="HAS_NO_RESTRICTIONS"/>
 *     &lt;enumeration value="HAS_NO_RESTRICTIONS_AND_CAN_NOT_ADD_ANY"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "restrictionType")
@XmlEnum
public enum RestrictionType {

    HAS_RESTRICTIONS,
    HAS_NO_RESTRICTIONS,
    HAS_NO_RESTRICTIONS_AND_CAN_NOT_ADD_ANY;

    public String value() {
        return name();
    }

    public static RestrictionType fromValue(String v) {
        return valueOf(v);
    }

}
