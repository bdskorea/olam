
package com.blackducksoftware.sdk.protex.license;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for permittedOrRequired.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="permittedOrRequired">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NOT_PERMITTED"/>
 *     &lt;enumeration value="PERMITTED"/>
 *     &lt;enumeration value="REQUIRED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "permittedOrRequired")
@XmlEnum
public enum PermittedOrRequired {

    NOT_PERMITTED,
    PERMITTED,
    REQUIRED;

    public String value() {
        return name();
    }

    public static PermittedOrRequired fromValue(String v) {
        return valueOf(v);
    }

}
