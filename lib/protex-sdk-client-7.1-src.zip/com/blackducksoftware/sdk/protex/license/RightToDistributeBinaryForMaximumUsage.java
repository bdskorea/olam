
package com.blackducksoftware.sdk.protex.license;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for rightToDistributeBinaryForMaximumUsage.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="rightToDistributeBinaryForMaximumUsage">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NON_COMMERCIAL_OR_PERSONAL_USE"/>
 *     &lt;enumeration value="INTERNAL_EVALUATION"/>
 *     &lt;enumeration value="INTERNAL_PRODUCTION_USE"/>
 *     &lt;enumeration value="ANY"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "rightToDistributeBinaryForMaximumUsage")
@XmlEnum
public enum RightToDistributeBinaryForMaximumUsage {

    NON_COMMERCIAL_OR_PERSONAL_USE,
    INTERNAL_EVALUATION,
    INTERNAL_PRODUCTION_USE,
    ANY;

    public String value() {
        return name();
    }

    public static RightToDistributeBinaryForMaximumUsage fromValue(String v) {
        return valueOf(v);
    }

}
