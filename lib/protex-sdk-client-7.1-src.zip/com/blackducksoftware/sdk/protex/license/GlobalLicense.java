
package com.blackducksoftware.sdk.protex.license;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.blackducksoftware.sdk.protex.policy.Adapter1;


/**
 * <p>Java class for globalLicense complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="globalLicense">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v7.0:license}license">
 *       &lt;sequence>
 *         &lt;element name="approvalDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="approvalState" type="{urn:protex.blackducksoftware.com:sdk:v7.0:license}licenseApprovalState" minOccurs="0"/>
 *         &lt;element name="approvedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="comment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="explanation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="licenseCodeSharingRequirement" type="{urn:protex.blackducksoftware.com:sdk:v7.0:license}licenseCodeSharingRequirement" minOccurs="0"/>
 *         &lt;element name="licenseOwnership" type="{urn:protex.blackducksoftware.com:sdk:v7.0:license}licenseOwnership" minOccurs="0"/>
 *         &lt;element name="suffix" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "globalLicense", propOrder = {
    "approvalDate",
    "approvalState",
    "approvedBy",
    "comment",
    "explanation",
    "licenseCodeSharingRequirement",
    "licenseOwnership",
    "suffix"
})
public class GlobalLicense
    extends License
{

    @XmlElement(type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date approvalDate;
    protected LicenseApprovalState approvalState;
    protected String approvedBy;
    protected String comment;
    protected String explanation;
    protected LicenseCodeSharingRequirement licenseCodeSharingRequirement;
    protected LicenseOwnership licenseOwnership;
    protected String suffix;

    /**
     * Gets the value of the approvalDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getApprovalDate() {
        return approvalDate;
    }

    /**
     * Sets the value of the approvalDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApprovalDate(Date value) {
        this.approvalDate = value;
    }

    /**
     * Gets the value of the approvalState property.
     * 
     * @return
     *     possible object is
     *     {@link LicenseApprovalState }
     *     
     */
    public LicenseApprovalState getApprovalState() {
        return approvalState;
    }

    /**
     * Sets the value of the approvalState property.
     * 
     * @param value
     *     allowed object is
     *     {@link LicenseApprovalState }
     *     
     */
    public void setApprovalState(LicenseApprovalState value) {
        this.approvalState = value;
    }

    /**
     * Gets the value of the approvedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApprovedBy() {
        return approvedBy;
    }

    /**
     * Sets the value of the approvedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApprovedBy(String value) {
        this.approvedBy = value;
    }

    /**
     * Gets the value of the comment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets the value of the comment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComment(String value) {
        this.comment = value;
    }

    /**
     * Gets the value of the explanation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExplanation() {
        return explanation;
    }

    /**
     * Sets the value of the explanation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExplanation(String value) {
        this.explanation = value;
    }

    /**
     * Gets the value of the licenseCodeSharingRequirement property.
     * 
     * @return
     *     possible object is
     *     {@link LicenseCodeSharingRequirement }
     *     
     */
    public LicenseCodeSharingRequirement getLicenseCodeSharingRequirement() {
        return licenseCodeSharingRequirement;
    }

    /**
     * Sets the value of the licenseCodeSharingRequirement property.
     * 
     * @param value
     *     allowed object is
     *     {@link LicenseCodeSharingRequirement }
     *     
     */
    public void setLicenseCodeSharingRequirement(LicenseCodeSharingRequirement value) {
        this.licenseCodeSharingRequirement = value;
    }

    /**
     * Gets the value of the licenseOwnership property.
     * 
     * @return
     *     possible object is
     *     {@link LicenseOwnership }
     *     
     */
    public LicenseOwnership getLicenseOwnership() {
        return licenseOwnership;
    }

    /**
     * Sets the value of the licenseOwnership property.
     * 
     * @param value
     *     allowed object is
     *     {@link LicenseOwnership }
     *     
     */
    public void setLicenseOwnership(LicenseOwnership value) {
        this.licenseOwnership = value;
    }

    /**
     * Gets the value of the suffix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuffix() {
        return suffix;
    }

    /**
     * Sets the value of the suffix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuffix(String value) {
        this.suffix = value;
    }

}
