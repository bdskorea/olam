
package com.blackducksoftware.sdk.protex.comparison;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getFileDifferences complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getFileDifferences">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="leftFile" type="{urn:protex.blackducksoftware.com:sdk:v7.0:comparison}protexFile" minOccurs="0"/>
 *         &lt;element name="rightFile" type="{urn:protex.blackducksoftware.com:sdk:v7.0:comparison}protexFile" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getFileDifferences", propOrder = {
    "leftFile",
    "rightFile"
})
public class GetFileDifferences {

    protected ProtexFile leftFile;
    protected ProtexFile rightFile;

    /**
     * Gets the value of the leftFile property.
     * 
     * @return
     *     possible object is
     *     {@link ProtexFile }
     *     
     */
    public ProtexFile getLeftFile() {
        return leftFile;
    }

    /**
     * Sets the value of the leftFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtexFile }
     *     
     */
    public void setLeftFile(ProtexFile value) {
        this.leftFile = value;
    }

    /**
     * Gets the value of the rightFile property.
     * 
     * @return
     *     possible object is
     *     {@link ProtexFile }
     *     
     */
    public ProtexFile getRightFile() {
        return rightFile;
    }

    /**
     * Sets the value of the rightFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtexFile }
     *     
     */
    public void setRightFile(ProtexFile value) {
        this.rightFile = value;
    }

}
