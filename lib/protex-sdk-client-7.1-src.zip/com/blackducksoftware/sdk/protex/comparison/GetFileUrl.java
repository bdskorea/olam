
package com.blackducksoftware.sdk.protex.comparison;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getFileUrl complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getFileUrl">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="file" type="{urn:protex.blackducksoftware.com:sdk:v7.0:comparison}protexFile" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getFileUrl", propOrder = {
    "file"
})
public class GetFileUrl {

    protected ProtexFile file;

    /**
     * Gets the value of the file property.
     * 
     * @return
     *     possible object is
     *     {@link ProtexFile }
     *     
     */
    public ProtexFile getFile() {
        return file;
    }

    /**
     * Sets the value of the file property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtexFile }
     *     
     */
    public void setFile(ProtexFile value) {
        this.file = value;
    }

}
