
package com.blackducksoftware.sdk.protex.comparison;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for protexFileSourceType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="protexFileSourceType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PROJECT"/>
 *     &lt;enumeration value="STANDARD_COMPONENT"/>
 *     &lt;enumeration value="CUSTOM_COMPONENT"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "protexFileSourceType")
@XmlEnum
public enum ProtexFileSourceType {

    PROJECT,
    STANDARD_COMPONENT,
    CUSTOM_COMPONENT;

    public String value() {
        return name();
    }

    public static ProtexFileSourceType fromValue(String v) {
        return valueOf(v);
    }

}
