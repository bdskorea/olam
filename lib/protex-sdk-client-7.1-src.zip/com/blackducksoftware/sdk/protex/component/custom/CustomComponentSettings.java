
package com.blackducksoftware.sdk.protex.component.custom;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.CodePrintSourceUploadOption;
import com.blackducksoftware.sdk.protex.common.ComponentKey;
import com.blackducksoftware.sdk.protex.common.ExpandArchivesOption;
import com.blackducksoftware.sdk.protex.project.AnalysisSourceLocation;


/**
 * <p>Java class for customComponentSettings complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="customComponentSettings">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="analysisSourceLocation" type="{urn:protex.blackducksoftware.com:sdk:v7.0:project}analysisSourceLocation" minOccurs="0"/>
 *         &lt;element name="codePrintSourceUploadOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}codePrintSourceUploadOption" minOccurs="0"/>
 *         &lt;element name="componentKey" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}componentKey" minOccurs="0"/>
 *         &lt;element name="decompressCompressedFilesOption" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="expandArchivesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}expandArchivesOption" minOccurs="0"/>
 *         &lt;element name="fileMatchesOption" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="originalCode" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="snippetMatchesOption" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "customComponentSettings", namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponent", propOrder = {
    "analysisSourceLocation",
    "codePrintSourceUploadOption",
    "componentKey",
    "decompressCompressedFilesOption",
    "expandArchivesOption",
    "fileMatchesOption",
    "originalCode",
    "snippetMatchesOption"
})
public class CustomComponentSettings {

    protected AnalysisSourceLocation analysisSourceLocation;
    protected CodePrintSourceUploadOption codePrintSourceUploadOption;
    protected ComponentKey componentKey;
    protected Boolean decompressCompressedFilesOption;
    protected ExpandArchivesOption expandArchivesOption;
    protected Boolean fileMatchesOption;
    protected Boolean originalCode;
    protected Boolean snippetMatchesOption;

    /**
     * Gets the value of the analysisSourceLocation property.
     * 
     * @return
     *     possible object is
     *     {@link AnalysisSourceLocation }
     *     
     */
    public AnalysisSourceLocation getAnalysisSourceLocation() {
        return analysisSourceLocation;
    }

    /**
     * Sets the value of the analysisSourceLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnalysisSourceLocation }
     *     
     */
    public void setAnalysisSourceLocation(AnalysisSourceLocation value) {
        this.analysisSourceLocation = value;
    }

    /**
     * Gets the value of the codePrintSourceUploadOption property.
     * 
     * @return
     *     possible object is
     *     {@link CodePrintSourceUploadOption }
     *     
     */
    public CodePrintSourceUploadOption getCodePrintSourceUploadOption() {
        return codePrintSourceUploadOption;
    }

    /**
     * Sets the value of the codePrintSourceUploadOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link CodePrintSourceUploadOption }
     *     
     */
    public void setCodePrintSourceUploadOption(CodePrintSourceUploadOption value) {
        this.codePrintSourceUploadOption = value;
    }

    /**
     * Gets the value of the componentKey property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentKey }
     *     
     */
    public ComponentKey getComponentKey() {
        return componentKey;
    }

    /**
     * Sets the value of the componentKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentKey }
     *     
     */
    public void setComponentKey(ComponentKey value) {
        this.componentKey = value;
    }

    /**
     * Gets the value of the decompressCompressedFilesOption property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDecompressCompressedFilesOption() {
        return decompressCompressedFilesOption;
    }

    /**
     * Sets the value of the decompressCompressedFilesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDecompressCompressedFilesOption(Boolean value) {
        this.decompressCompressedFilesOption = value;
    }

    /**
     * Gets the value of the expandArchivesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ExpandArchivesOption }
     *     
     */
    public ExpandArchivesOption getExpandArchivesOption() {
        return expandArchivesOption;
    }

    /**
     * Sets the value of the expandArchivesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExpandArchivesOption }
     *     
     */
    public void setExpandArchivesOption(ExpandArchivesOption value) {
        this.expandArchivesOption = value;
    }

    /**
     * Gets the value of the fileMatchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFileMatchesOption() {
        return fileMatchesOption;
    }

    /**
     * Sets the value of the fileMatchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFileMatchesOption(Boolean value) {
        this.fileMatchesOption = value;
    }

    /**
     * Gets the value of the originalCode property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isOriginalCode() {
        return originalCode;
    }

    /**
     * Sets the value of the originalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setOriginalCode(Boolean value) {
        this.originalCode = value;
    }

    /**
     * Gets the value of the snippetMatchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSnippetMatchesOption() {
        return snippetMatchesOption;
    }

    /**
     * Sets the value of the snippetMatchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSnippetMatchesOption(Boolean value) {
        this.snippetMatchesOption = value;
    }

}
