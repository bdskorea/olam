
package com.blackducksoftware.sdk.protex.component;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.ComponentKey;
import com.blackducksoftware.sdk.protex.common.DownloadHashType;


/**
 * <p>Java class for getHashesByComponent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getHashesByComponent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="hashType" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}downloadHashType" minOccurs="0"/>
 *         &lt;element name="componentKey" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}componentKey" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getHashesByComponent", propOrder = {
    "hashType",
    "componentKey"
})
public class GetHashesByComponent {

    protected DownloadHashType hashType;
    protected ComponentKey componentKey;

    /**
     * Gets the value of the hashType property.
     * 
     * @return
     *     possible object is
     *     {@link DownloadHashType }
     *     
     */
    public DownloadHashType getHashType() {
        return hashType;
    }

    /**
     * Sets the value of the hashType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DownloadHashType }
     *     
     */
    public void setHashType(DownloadHashType value) {
        this.hashType = value;
    }

    /**
     * Gets the value of the componentKey property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentKey }
     *     
     */
    public ComponentKey getComponentKey() {
        return componentKey;
    }

    /**
     * Sets the value of the componentKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentKey }
     *     
     */
    public void setComponentKey(ComponentKey value) {
        this.componentKey = value;
    }

}
