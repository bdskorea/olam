
package com.blackducksoftware.sdk.protex.component;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.ComponentKey;


/**
 * <p>Java class for resetComponent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="resetComponent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="standardComponentKey" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}componentKey" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "resetComponent", propOrder = {
    "standardComponentKey"
})
public class ResetComponent {

    protected ComponentKey standardComponentKey;

    /**
     * Gets the value of the standardComponentKey property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentKey }
     *     
     */
    public ComponentKey getStandardComponentKey() {
        return standardComponentKey;
    }

    /**
     * Sets the value of the standardComponentKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentKey }
     *     
     */
    public void setStandardComponentKey(ComponentKey value) {
        this.standardComponentKey = value;
    }

}
