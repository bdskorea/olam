
package com.blackducksoftware.sdk.protex.component;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.obligation.AssignedObligationRequest;


/**
 * <p>Java class for updateComponentObligation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateComponentObligation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="componentId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="obligationId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="obligationUpdateRequest" type="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}assignedObligationRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateComponentObligation", propOrder = {
    "componentId",
    "obligationId",
    "obligationUpdateRequest"
})
public class UpdateComponentObligation {

    protected String componentId;
    protected String obligationId;
    protected AssignedObligationRequest obligationUpdateRequest;

    /**
     * Gets the value of the componentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComponentId() {
        return componentId;
    }

    /**
     * Sets the value of the componentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComponentId(String value) {
        this.componentId = value;
    }

    /**
     * Gets the value of the obligationId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObligationId() {
        return obligationId;
    }

    /**
     * Sets the value of the obligationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObligationId(String value) {
        this.obligationId = value;
    }

    /**
     * Gets the value of the obligationUpdateRequest property.
     * 
     * @return
     *     possible object is
     *     {@link AssignedObligationRequest }
     *     
     */
    public AssignedObligationRequest getObligationUpdateRequest() {
        return obligationUpdateRequest;
    }

    /**
     * Sets the value of the obligationUpdateRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link AssignedObligationRequest }
     *     
     */
    public void setObligationUpdateRequest(AssignedObligationRequest value) {
        this.obligationUpdateRequest = value;
    }

}
