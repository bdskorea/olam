
package com.blackducksoftware.sdk.protex.component;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.ComponentKey;


/**
 * <p>Java class for updateComponent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateComponent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="componentKey" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}componentKey" minOccurs="0"/>
 *         &lt;element name="componentUpdateRequest" type="{urn:protex.blackducksoftware.com:sdk:v7.0:component}componentRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateComponent", propOrder = {
    "componentKey",
    "componentUpdateRequest"
})
public class UpdateComponent {

    protected ComponentKey componentKey;
    protected ComponentRequest componentUpdateRequest;

    /**
     * Gets the value of the componentKey property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentKey }
     *     
     */
    public ComponentKey getComponentKey() {
        return componentKey;
    }

    /**
     * Sets the value of the componentKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentKey }
     *     
     */
    public void setComponentKey(ComponentKey value) {
        this.componentKey = value;
    }

    /**
     * Gets the value of the componentUpdateRequest property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentRequest }
     *     
     */
    public ComponentRequest getComponentUpdateRequest() {
        return componentUpdateRequest;
    }

    /**
     * Sets the value of the componentUpdateRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentRequest }
     *     
     */
    public void setComponentUpdateRequest(ComponentRequest value) {
        this.componentUpdateRequest = value;
    }

}
