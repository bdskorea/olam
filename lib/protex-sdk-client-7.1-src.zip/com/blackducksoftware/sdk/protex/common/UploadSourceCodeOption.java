
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for uploadSourceCodeOption.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="uploadSourceCodeOption">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ENABLED_ENCRYPTED"/>
 *     &lt;enumeration value="ENABLED_NOT_ENCRYPTED"/>
 *     &lt;enumeration value="DISABLED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "uploadSourceCodeOption")
@XmlEnum
public enum UploadSourceCodeOption {

    ENABLED_ENCRYPTED,
    ENABLED_NOT_ENCRYPTED,
    DISABLED;

    public String value() {
        return name();
    }

    public static UploadSourceCodeOption fromValue(String v) {
        return valueOf(v);
    }

}
