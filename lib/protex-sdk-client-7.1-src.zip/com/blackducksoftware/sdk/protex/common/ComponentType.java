
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for componentType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="componentType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="STANDARD"/>
 *     &lt;enumeration value="STANDARD_MODIFIED"/>
 *     &lt;enumeration value="CUSTOM"/>
 *     &lt;enumeration value="PROJECT"/>
 *     &lt;enumeration value="LOCAL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "componentType")
@XmlEnum
public enum ComponentType {

    STANDARD,
    STANDARD_MODIFIED,
    CUSTOM,
    PROJECT,
    LOCAL;

    public String value() {
        return name();
    }

    public static ComponentType fromValue(String v) {
        return valueOf(v);
    }

}
