
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for analysisPhase.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="analysisPhase">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="INITIALIZING"/>
 *     &lt;enumeration value="ASSESSING"/>
 *     &lt;enumeration value="SCANNING"/>
 *     &lt;enumeration value="ANALYZING"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "analysisPhase")
@XmlEnum
public enum AnalysisPhase {

    INITIALIZING,
    ASSESSING,
    SCANNING,
    ANALYZING;

    public String value() {
        return name();
    }

    public static AnalysisPhase fromValue(String v) {
        return valueOf(v);
    }

}
