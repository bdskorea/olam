
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for approvalState.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="approvalState">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="APPROVED"/>
 *     &lt;enumeration value="DIS_APPROVED"/>
 *     &lt;enumeration value="NOT_REVIEWED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "approvalState")
@XmlEnum
public enum ApprovalState {

    APPROVED,
    DIS_APPROVED,
    NOT_REVIEWED;

    public String value() {
        return name();
    }

    public static ApprovalState fromValue(String v) {
        return valueOf(v);
    }

}
