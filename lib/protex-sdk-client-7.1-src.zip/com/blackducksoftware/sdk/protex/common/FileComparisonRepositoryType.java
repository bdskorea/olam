
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for fileComparisonRepositoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="fileComparisonRepositoryType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="AUTOMATIC"/>
 *     &lt;enumeration value="REMOTE_SERVER"/>
 *     &lt;enumeration value="LOCAL_SERVER"/>
 *     &lt;enumeration value="OTHER"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "fileComparisonRepositoryType")
@XmlEnum
public enum FileComparisonRepositoryType {

    AUTOMATIC,
    REMOTE_SERVER,
    LOCAL_SERVER,
    OTHER;

    public String value() {
        return name();
    }

    public static FileComparisonRepositoryType fromValue(String v) {
        return valueOf(v);
    }

}
