
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for forcibleComponentsReleasedOnOrAfterOption complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="forcibleComponentsReleasedOnOrAfterOption">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="forced" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="option" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}componentsReleasedOnOrAfterOption" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "forcibleComponentsReleasedOnOrAfterOption", propOrder = {
    "forced",
    "option"
})
public class ForcibleComponentsReleasedOnOrAfterOption {

    protected Boolean forced;
    protected ComponentsReleasedOnOrAfterOption option;

    /**
     * Gets the value of the forced property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isForced() {
        return forced;
    }

    /**
     * Sets the value of the forced property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setForced(Boolean value) {
        this.forced = value;
    }

    /**
     * Gets the value of the option property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentsReleasedOnOrAfterOption }
     *     
     */
    public ComponentsReleasedOnOrAfterOption getOption() {
        return option;
    }

    /**
     * Sets the value of the option property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentsReleasedOnOrAfterOption }
     *     
     */
    public void setOption(ComponentsReleasedOnOrAfterOption value) {
        this.option = value;
    }

}
