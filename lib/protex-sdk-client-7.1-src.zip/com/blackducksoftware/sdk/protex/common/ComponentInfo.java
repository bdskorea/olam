
package com.blackducksoftware.sdk.protex.common;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.license.LicenseInfo;


/**
 * <p>Java class for componentInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="componentInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="approvalState" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}approvalState" minOccurs="0"/>
 *         &lt;element name="componentKey" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}componentKey" minOccurs="0"/>
 *         &lt;element name="componentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="componentType" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}componentType" minOccurs="0"/>
 *         &lt;element name="homePage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="licenses" type="{urn:protex.blackducksoftware.com:sdk:v7.0:license}licenseInfo" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="primaryLicenseId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="versionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "componentInfo", propOrder = {
    "approvalState",
    "componentKey",
    "componentName",
    "componentType",
    "homePage",
    "licenses",
    "primaryLicenseId",
    "versionName"
})
public class ComponentInfo {

    protected ApprovalState approvalState;
    protected ComponentKey componentKey;
    protected String componentName;
    protected ComponentType componentType;
    protected String homePage;
    @XmlElement(nillable = true)
    protected List<LicenseInfo> licenses;
    protected String primaryLicenseId;
    protected String versionName;

    /**
     * Gets the value of the approvalState property.
     * 
     * @return
     *     possible object is
     *     {@link ApprovalState }
     *     
     */
    public ApprovalState getApprovalState() {
        return approvalState;
    }

    /**
     * Sets the value of the approvalState property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApprovalState }
     *     
     */
    public void setApprovalState(ApprovalState value) {
        this.approvalState = value;
    }

    /**
     * Gets the value of the componentKey property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentKey }
     *     
     */
    public ComponentKey getComponentKey() {
        return componentKey;
    }

    /**
     * Sets the value of the componentKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentKey }
     *     
     */
    public void setComponentKey(ComponentKey value) {
        this.componentKey = value;
    }

    /**
     * Gets the value of the componentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComponentName() {
        return componentName;
    }

    /**
     * Sets the value of the componentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComponentName(String value) {
        this.componentName = value;
    }

    /**
     * Gets the value of the componentType property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentType }
     *     
     */
    public ComponentType getComponentType() {
        return componentType;
    }

    /**
     * Sets the value of the componentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentType }
     *     
     */
    public void setComponentType(ComponentType value) {
        this.componentType = value;
    }

    /**
     * Gets the value of the homePage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHomePage() {
        return homePage;
    }

    /**
     * Sets the value of the homePage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHomePage(String value) {
        this.homePage = value;
    }

    /**
     * Gets the value of the licenses property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the licenses property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLicenses().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LicenseInfo }
     * 
     * 
     */
    public List<LicenseInfo> getLicenses() {
        if (licenses == null) {
            licenses = new ArrayList<LicenseInfo>();
        }
        return this.licenses;
    }

    /**
     * Gets the value of the primaryLicenseId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryLicenseId() {
        return primaryLicenseId;
    }

    /**
     * Sets the value of the primaryLicenseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryLicenseId(String value) {
        this.primaryLicenseId = value;
    }

    /**
     * Gets the value of the versionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersionName() {
        return versionName;
    }

    /**
     * Sets the value of the versionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersionName(String value) {
        this.versionName = value;
    }

}
