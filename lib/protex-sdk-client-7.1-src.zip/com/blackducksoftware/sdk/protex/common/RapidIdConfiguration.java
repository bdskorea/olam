
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for rapidIdConfiguration complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="rapidIdConfiguration">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v7.0:common}rapidIdConfigurationRequest">
 *       &lt;sequence>
 *         &lt;element name="configurationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="originType" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}rapidIdConfigurationOriginType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rapidIdConfiguration", propOrder = {
    "configurationId",
    "originType"
})
public class RapidIdConfiguration
    extends RapidIdConfigurationRequest
{

    protected Long configurationId;
    protected RapidIdConfigurationOriginType originType;

    /**
     * Gets the value of the configurationId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getConfigurationId() {
        return configurationId;
    }

    /**
     * Sets the value of the configurationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setConfigurationId(Long value) {
        this.configurationId = value;
    }

    /**
     * Gets the value of the originType property.
     * 
     * @return
     *     possible object is
     *     {@link RapidIdConfigurationOriginType }
     *     
     */
    public RapidIdConfigurationOriginType getOriginType() {
        return originType;
    }

    /**
     * Sets the value of the originType property.
     * 
     * @param value
     *     allowed object is
     *     {@link RapidIdConfigurationOriginType }
     *     
     */
    public void setOriginType(RapidIdConfigurationOriginType value) {
        this.originType = value;
    }

}
