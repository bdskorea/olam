
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for detectFileChangesOption.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="detectFileChangesOption">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="MODIFICATION_TIME"/>
 *     &lt;enumeration value="CHECKSUM"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "detectFileChangesOption")
@XmlEnum
public enum DetectFileChangesOption {

    MODIFICATION_TIME,
    CHECKSUM;

    public String value() {
        return name();
    }

    public static DetectFileChangesOption fromValue(String v) {
        return valueOf(v);
    }

}
