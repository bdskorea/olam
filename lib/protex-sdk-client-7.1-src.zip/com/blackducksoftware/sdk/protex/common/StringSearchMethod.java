
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for stringSearchMethod.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="stringSearchMethod">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="LUCENE"/>
 *     &lt;enumeration value="REGULAR_EXPRESSION"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "stringSearchMethod")
@XmlEnum
public enum StringSearchMethod {

    LUCENE,
    REGULAR_EXPRESSION;

    public String value() {
        return name();
    }

    public static StringSearchMethod fromValue(String v) {
        return valueOf(v);
    }

}
