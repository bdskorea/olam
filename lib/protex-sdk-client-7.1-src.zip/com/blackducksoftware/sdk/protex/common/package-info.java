@javax.xml.bind.annotation.XmlSchema(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:common")
package com.blackducksoftware.sdk.protex.common;
