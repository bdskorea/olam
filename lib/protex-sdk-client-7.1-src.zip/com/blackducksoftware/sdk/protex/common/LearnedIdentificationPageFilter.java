
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for learnedIdentificationPageFilter complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="learnedIdentificationPageFilter">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v7.0:common}pageFilter">
 *       &lt;sequence>
 *         &lt;element name="sortedColumn" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}learnedIdentificationColumn" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "learnedIdentificationPageFilter", propOrder = {
    "sortedColumn"
})
public class LearnedIdentificationPageFilter
    extends PageFilter
{

    protected LearnedIdentificationColumn sortedColumn;

    /**
     * Gets the value of the sortedColumn property.
     * 
     * @return
     *     possible object is
     *     {@link LearnedIdentificationColumn }
     *     
     */
    public LearnedIdentificationColumn getSortedColumn() {
        return sortedColumn;
    }

    /**
     * Sets the value of the sortedColumn property.
     * 
     * @param value
     *     allowed object is
     *     {@link LearnedIdentificationColumn }
     *     
     */
    public void setSortedColumn(LearnedIdentificationColumn value) {
        this.sortedColumn = value;
    }

}
