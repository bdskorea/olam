
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.license.LicenseInfo;
import com.blackducksoftware.sdk.protex.project.codetree.discovery.DiscoveryType;
import com.blackducksoftware.sdk.protex.project.codetree.identification.IdentificationType;


/**
 * <p>Java class for learnedIdentification complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="learnedIdentification">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="comment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="discoveryType" type="{urn:protex.blackducksoftware.com:sdk:v7.0:discovery}discoveryType" minOccurs="0"/>
 *         &lt;element name="identificationType" type="{urn:protex.blackducksoftware.com:sdk:v7.0:identification}identificationType" minOccurs="0"/>
 *         &lt;element name="identificationUpdatedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="identificationUpdatedDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="identifiedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="identifiedComponentKey" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}componentKey" minOccurs="0"/>
 *         &lt;element name="identifiedDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="identifiedLicenseInfo" type="{urn:protex.blackducksoftware.com:sdk:v7.0:license}licenseInfo" minOccurs="0"/>
 *         &lt;element name="identifiedUsageLevel" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}usageLevel" minOccurs="0"/>
 *         &lt;element name="learnedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="learnedChecksum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="learnedDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="learnedFromProjectId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="learnedIdentificationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="learningUpdatedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="learningUpdatedDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "learnedIdentification", propOrder = {
    "comment",
    "discoveryType",
    "identificationType",
    "identificationUpdatedBy",
    "identificationUpdatedDate",
    "identifiedBy",
    "identifiedComponentKey",
    "identifiedDate",
    "identifiedLicenseInfo",
    "identifiedUsageLevel",
    "learnedBy",
    "learnedChecksum",
    "learnedDate",
    "learnedFromProjectId",
    "learnedIdentificationId",
    "learningUpdatedBy",
    "learningUpdatedDate"
})
@XmlSeeAlso({
    LearnedStringSearchIdentification.class,
    LearnedCodeMatchIdentification.class
})
public abstract class LearnedIdentification {

    protected String comment;
    protected DiscoveryType discoveryType;
    protected IdentificationType identificationType;
    protected String identificationUpdatedBy;
    protected String identificationUpdatedDate;
    protected String identifiedBy;
    protected ComponentKey identifiedComponentKey;
    protected String identifiedDate;
    protected LicenseInfo identifiedLicenseInfo;
    protected UsageLevel identifiedUsageLevel;
    protected String learnedBy;
    protected String learnedChecksum;
    protected String learnedDate;
    protected String learnedFromProjectId;
    protected Long learnedIdentificationId;
    protected String learningUpdatedBy;
    protected String learningUpdatedDate;

    /**
     * Gets the value of the comment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets the value of the comment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComment(String value) {
        this.comment = value;
    }

    /**
     * Gets the value of the discoveryType property.
     * 
     * @return
     *     possible object is
     *     {@link DiscoveryType }
     *     
     */
    public DiscoveryType getDiscoveryType() {
        return discoveryType;
    }

    /**
     * Sets the value of the discoveryType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DiscoveryType }
     *     
     */
    public void setDiscoveryType(DiscoveryType value) {
        this.discoveryType = value;
    }

    /**
     * Gets the value of the identificationType property.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationType }
     *     
     */
    public IdentificationType getIdentificationType() {
        return identificationType;
    }

    /**
     * Sets the value of the identificationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationType }
     *     
     */
    public void setIdentificationType(IdentificationType value) {
        this.identificationType = value;
    }

    /**
     * Gets the value of the identificationUpdatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificationUpdatedBy() {
        return identificationUpdatedBy;
    }

    /**
     * Sets the value of the identificationUpdatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificationUpdatedBy(String value) {
        this.identificationUpdatedBy = value;
    }

    /**
     * Gets the value of the identificationUpdatedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificationUpdatedDate() {
        return identificationUpdatedDate;
    }

    /**
     * Sets the value of the identificationUpdatedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificationUpdatedDate(String value) {
        this.identificationUpdatedDate = value;
    }

    /**
     * Gets the value of the identifiedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentifiedBy() {
        return identifiedBy;
    }

    /**
     * Sets the value of the identifiedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentifiedBy(String value) {
        this.identifiedBy = value;
    }

    /**
     * Gets the value of the identifiedComponentKey property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentKey }
     *     
     */
    public ComponentKey getIdentifiedComponentKey() {
        return identifiedComponentKey;
    }

    /**
     * Sets the value of the identifiedComponentKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentKey }
     *     
     */
    public void setIdentifiedComponentKey(ComponentKey value) {
        this.identifiedComponentKey = value;
    }

    /**
     * Gets the value of the identifiedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentifiedDate() {
        return identifiedDate;
    }

    /**
     * Sets the value of the identifiedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentifiedDate(String value) {
        this.identifiedDate = value;
    }

    /**
     * Gets the value of the identifiedLicenseInfo property.
     * 
     * @return
     *     possible object is
     *     {@link LicenseInfo }
     *     
     */
    public LicenseInfo getIdentifiedLicenseInfo() {
        return identifiedLicenseInfo;
    }

    /**
     * Sets the value of the identifiedLicenseInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link LicenseInfo }
     *     
     */
    public void setIdentifiedLicenseInfo(LicenseInfo value) {
        this.identifiedLicenseInfo = value;
    }

    /**
     * Gets the value of the identifiedUsageLevel property.
     * 
     * @return
     *     possible object is
     *     {@link UsageLevel }
     *     
     */
    public UsageLevel getIdentifiedUsageLevel() {
        return identifiedUsageLevel;
    }

    /**
     * Sets the value of the identifiedUsageLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link UsageLevel }
     *     
     */
    public void setIdentifiedUsageLevel(UsageLevel value) {
        this.identifiedUsageLevel = value;
    }

    /**
     * Gets the value of the learnedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLearnedBy() {
        return learnedBy;
    }

    /**
     * Sets the value of the learnedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLearnedBy(String value) {
        this.learnedBy = value;
    }

    /**
     * Gets the value of the learnedChecksum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLearnedChecksum() {
        return learnedChecksum;
    }

    /**
     * Sets the value of the learnedChecksum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLearnedChecksum(String value) {
        this.learnedChecksum = value;
    }

    /**
     * Gets the value of the learnedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLearnedDate() {
        return learnedDate;
    }

    /**
     * Sets the value of the learnedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLearnedDate(String value) {
        this.learnedDate = value;
    }

    /**
     * Gets the value of the learnedFromProjectId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLearnedFromProjectId() {
        return learnedFromProjectId;
    }

    /**
     * Sets the value of the learnedFromProjectId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLearnedFromProjectId(String value) {
        this.learnedFromProjectId = value;
    }

    /**
     * Gets the value of the learnedIdentificationId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLearnedIdentificationId() {
        return learnedIdentificationId;
    }

    /**
     * Sets the value of the learnedIdentificationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLearnedIdentificationId(Long value) {
        this.learnedIdentificationId = value;
    }

    /**
     * Gets the value of the learningUpdatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLearningUpdatedBy() {
        return learningUpdatedBy;
    }

    /**
     * Sets the value of the learningUpdatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLearningUpdatedBy(String value) {
        this.learningUpdatedBy = value;
    }

    /**
     * Gets the value of the learningUpdatedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLearningUpdatedDate() {
        return learningUpdatedDate;
    }

    /**
     * Sets the value of the learningUpdatedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLearningUpdatedDate(String value) {
        this.learningUpdatedDate = value;
    }

}
