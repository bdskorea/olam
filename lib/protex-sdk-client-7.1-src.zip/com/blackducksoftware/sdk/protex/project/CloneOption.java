
package com.blackducksoftware.sdk.protex.project;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for cloneOption.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="cloneOption">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ANALYSIS_RESULTS"/>
 *     &lt;enumeration value="COMPLETED_WORK"/>
 *     &lt;enumeration value="ASSIGNED_USERS"/>
 *     &lt;enumeration value="LINK_IDENTIFICATIONS_TO_ORIGINAL_PROJECT"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "cloneOption")
@XmlEnum
public enum CloneOption {

    ANALYSIS_RESULTS,
    COMPLETED_WORK,
    ASSIGNED_USERS,
    LINK_IDENTIFICATIONS_TO_ORIGINAL_PROJECT;

    public String value() {
        return name();
    }

    public static CloneOption fromValue(String v) {
        return valueOf(v);
    }

}
