
package com.blackducksoftware.sdk.protex.project;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for analysisSourceRepository.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="analysisSourceRepository">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="REMOTE_SERVER"/>
 *     &lt;enumeration value="NETWORK_FOLDER"/>
 *     &lt;enumeration value="LOCAL_PROXY"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "analysisSourceRepository")
@XmlEnum
public enum AnalysisSourceRepository {

    REMOTE_SERVER,
    NETWORK_FOLDER,
    LOCAL_PROXY;

    public String value() {
        return name();
    }

    public static AnalysisSourceRepository fromValue(String v) {
        return valueOf(v);
    }

}
