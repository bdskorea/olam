
package com.blackducksoftware.sdk.protex.project;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for createProjectFromTemplate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createProjectFromTemplate">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="templateId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="newProjectSettings" type="{urn:protex.blackducksoftware.com:sdk:v7.0:project}projectRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createProjectFromTemplate", propOrder = {
    "templateId",
    "newProjectSettings"
})
public class CreateProjectFromTemplate {

    protected String templateId;
    protected ProjectRequest newProjectSettings;

    /**
     * Gets the value of the templateId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplateId() {
        return templateId;
    }

    /**
     * Sets the value of the templateId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplateId(String value) {
        this.templateId = value;
    }

    /**
     * Gets the value of the newProjectSettings property.
     * 
     * @return
     *     possible object is
     *     {@link ProjectRequest }
     *     
     */
    public ProjectRequest getNewProjectSettings() {
        return newProjectSettings;
    }

    /**
     * Sets the value of the newProjectSettings property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProjectRequest }
     *     
     */
    public void setNewProjectSettings(ProjectRequest value) {
        this.newProjectSettings = value;
    }

}
