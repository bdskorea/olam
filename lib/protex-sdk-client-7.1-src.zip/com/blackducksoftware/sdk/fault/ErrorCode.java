
package com.blackducksoftware.sdk.fault;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for errorCode.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="errorCode">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="SERVER_REGISTRATION_ERROR"/>
 *     &lt;enumeration value="SERVER_PERFORMING_UPDATE"/>
 *     &lt;enumeration value="NO_ANALYSIS_RUNNING"/>
 *     &lt;enumeration value="ANALYSIS_ALREADY_RUNNING"/>
 *     &lt;enumeration value="INVALID_SOURCE_LOCATION_FOR_SCAN"/>
 *     &lt;enumeration value="PROJECT_COULD_NOT_BE_LOCKED"/>
 *     &lt;enumeration value="LICENSE_NAME_TOO_LONG"/>
 *     &lt;enumeration value="LICENSE_TYPE_STANDARD_CANT_CHANGE_NAME"/>
 *     &lt;enumeration value="TAG_NOT_FOUND"/>
 *     &lt;enumeration value="OBLIGATION_IS_REFERENCED"/>
 *     &lt;enumeration value="OBLIGATION_NOT_ASSIGNED"/>
 *     &lt;enumeration value="DUPLICATE_LICENSE_NAME"/>
 *     &lt;enumeration value="LICENSE_NOT_FOUND"/>
 *     &lt;enumeration value="LICENSE_IN_USE"/>
 *     &lt;enumeration value="CAN_NOT_RESET_CUSTOM_LICENSE"/>
 *     &lt;enumeration value="DUPLICATE_OBLIGATION_CATEGORY"/>
 *     &lt;enumeration value="OBLIGATION_CATEGORY_NOT_FOUND"/>
 *     &lt;enumeration value="OBLIGATION_CATEGORY_IN_USE"/>
 *     &lt;enumeration value="OBLIGATION_CATEGORY_CAN_NOT_BE_DELETED"/>
 *     &lt;enumeration value="DUPLICATE_OBLIGATION_NAME"/>
 *     &lt;enumeration value="DUPLICATE_OBLIGATION_ASSIGNMENT"/>
 *     &lt;enumeration value="INVALID_OBLIGATION_NAME"/>
 *     &lt;enumeration value="OBLIGATION_NOT_FOUND"/>
 *     &lt;enumeration value="OBLIGATION_IN_USE_BY_PROJECTS"/>
 *     &lt;enumeration value="OBLIGATION_IN_USE_BY_LICENSES"/>
 *     &lt;enumeration value="RAPID_ID_CONFIGURATION_NOT_FOUND"/>
 *     &lt;enumeration value="RAPID_ID_CONFIGURATION_DUPLICATE_NAME"/>
 *     &lt;enumeration value="RAPID_ID_CONFIGURATION_DUPLICATE_ASSOCIATION"/>
 *     &lt;enumeration value="RAPID_ID_OPERATION_TYPE_DUPLICATE"/>
 *     &lt;enumeration value="LEARNED_IDENTIFICATION_NOT_FOUND"/>
 *     &lt;enumeration value="USER_NOT_ASSIGNED_TO_PROJECT"/>
 *     &lt;enumeration value="UNKNOWN_ANALYSIS_DATABASE_OPTION"/>
 *     &lt;enumeration value="STRING_SEARCH_PATTERN_UPDATE_OF_STANDARD_PATTERN_NOT_ALLOWED"/>
 *     &lt;enumeration value="CUSTOM_COMPONENT_IN_USE"/>
 *     &lt;enumeration value="CUSTOM_COMPONENT_HAS_NO_SOURCE"/>
 *     &lt;enumeration value="DUPLICATE_TEMPLATE_TITLE"/>
 *     &lt;enumeration value="REPORT_TEMPLATE_NOT_FOUND"/>
 *     &lt;enumeration value="DUPLICATE_PROJECT_NAME"/>
 *     &lt;enumeration value="PROJECT_ANALYSIS_LOCAL_SOURCE_NOT_SUPPORTED"/>
 *     &lt;enumeration value="OPTIONS_SETTING_NOT_ALLOWED"/>
 *     &lt;enumeration value="OPTIONS_CANNOT_BE_FORCED_FOR_LOCAL_SEARCH_SETTINGS"/>
 *     &lt;enumeration value="DUPLICATE_STRING_SEARCH_PATTERN_NAME"/>
 *     &lt;enumeration value="DUPLICATE_FILE_DISCOVERY_PATTERN_NAME"/>
 *     &lt;enumeration value="LINKING_PROJECTS_FORCES_CLONING_OF_WORK_RESULTS"/>
 *     &lt;enumeration value="PROJECT_NOT_YET_ANALYZED"/>
 *     &lt;enumeration value="DUPLICATE_USER_ASSIGNMENT"/>
 *     &lt;enumeration value="PROJECT_NAME_TOO_LONG"/>
 *     &lt;enumeration value="INVALID_PROJECT_NAME"/>
 *     &lt;enumeration value="PROJECT_NOT_FOUND"/>
 *     &lt;enumeration value="PROJECT_SYNCID_INVALID"/>
 *     &lt;enumeration value="LINKING_GLOBALLY_DISABLED"/>
 *     &lt;enumeration value="PROJECT_IN_USE"/>
 *     &lt;enumeration value="STRING_SEARCH_PATTERN_NAME_TOO_LONG"/>
 *     &lt;enumeration value="ROLE_NOT_FOUND"/>
 *     &lt;enumeration value="MINIMUM_ONE_ADMIN_USER"/>
 *     &lt;enumeration value="REMOVE_SELF_AS_ADMIN_USER"/>
 *     &lt;enumeration value="DUPLICATE_EMAIL_ADDRESS"/>
 *     &lt;enumeration value="EMAIL_TOO_LONG"/>
 *     &lt;enumeration value="FIRST_NAME_TOO_LONG"/>
 *     &lt;enumeration value="LAST_NAME_TOO_LONG"/>
 *     &lt;enumeration value="EXTERNAL_AUTHENTICATION_ID_TOO_LONG"/>
 *     &lt;enumeration value="EXTERNAL_AUTHENTICATION_ID_DUPLICATE"/>
 *     &lt;enumeration value="INVALID_EMAIL_ADDRESS"/>
 *     &lt;enumeration value="USER_NOT_FOUND"/>
 *     &lt;enumeration value="PASSWORD_TOO_SHORT"/>
 *     &lt;enumeration value="PASSWORD_TOO_LONG"/>
 *     &lt;enumeration value="STRING_SEARCH_DISCOVERY_NOT_FOUND"/>
 *     &lt;enumeration value="STRING_SEARCH_REQUIRES_UPLOADED_SOURCE"/>
 *     &lt;enumeration value="USAGE_LEVEL_INVALID_FOR_GIVEN_ID"/>
 *     &lt;enumeration value="CANNOT_COPY_ID_PROJECT_SYNCHRONIZED"/>
 *     &lt;enumeration value="CODE_TREE_PATH_NOT_FOUND"/>
 *     &lt;enumeration value="CODE_TREE_GUARANTEED_EMPTY_RESULT"/>
 *     &lt;enumeration value="NO_FILE_CONTENT"/>
 *     &lt;enumeration value="CODE_TREE_PARENT_PATH_NOT_FOUND"/>
 *     &lt;enumeration value="DUPLICATE_COMPONENT_NAME"/>
 *     &lt;enumeration value="COMPONENT_NAME_TOO_LONG"/>
 *     &lt;enumeration value="INVALID_COMPONENT_NAME"/>
 *     &lt;enumeration value="COMPONENT_NOT_FOUND"/>
 *     &lt;enumeration value="COMPONENT_VERSION_NOT_FOUND"/>
 *     &lt;enumeration value="OPTION_IS_FORCED"/>
 *     &lt;enumeration value="FILE_DISCOVERY_PATTERN_NOT_FOUND"/>
 *     &lt;enumeration value="STRING_SEARCH_PATTERN_NOT_FOUND"/>
 *     &lt;enumeration value="UNEXPECTED_EXCEPTION_ERROR"/>
 *     &lt;enumeration value="UNKNOWN_REPORT_SECTION_ERROR"/>
 *     &lt;enumeration value="PROTEX_FILE_SOURCE_NOT_AVAILABLE"/>
 *     &lt;enumeration value="NOT_A_FILE_PATH"/>
 *     &lt;enumeration value="ARGUMENT_VALUE_INVALID"/>
 *     &lt;enumeration value="METHOD_NOT_YET_IMPLEMENTED"/>
 *     &lt;enumeration value="ARGUMENT_NOT_YET_IMPLEMENTED"/>
 *     &lt;enumeration value="ARGUMENT_VALUE_NOT_YET_IMPLEMENTED"/>
 *     &lt;enumeration value="INVALID_CREDENTIALS"/>
 *     &lt;enumeration value="INSUFFICIENT_PERMISSION"/>
 *     &lt;enumeration value="UNKNOWN_ERROR"/>
 *     &lt;enumeration value="BOM_REFRESH_NOT_FINISHED"/>
 *     &lt;enumeration value="BOM_COMPONENT_PROJECT_CANT_UPDATE"/>
 *     &lt;enumeration value="UPDATE_BOM_COMPONENT_VERSION_NAME_OF_COMPONENT_VERSION_PROHIBITED"/>
 *     &lt;enumeration value="TODO_CONVERT_EXCEPTION"/>
 *     &lt;enumeration value="UNEXPECTED_RETURN_VALUE_ERROR"/>
 *     &lt;enumeration value="OUT_OF_MEMORY_ERROR"/>
 *     &lt;enumeration value="NO_SESSION_ID"/>
 *     &lt;enumeration value="INVALID_SORT_KEY"/>
 *     &lt;enumeration value="CAN_NOT_OPEN_TEMP_FILE"/>
 *     &lt;enumeration value="CODEMATCH_SELF_IDENTIFICATION_MUST_MATCH_DECLARED_LICENSE"/>
 *     &lt;enumeration value="IDENTIFICATION_NOT_FOUND"/>
 *     &lt;enumeration value="IDENTIFICATION_LEARNING_CONFLICT"/>
 *     &lt;enumeration value="EXTERNAL_NAMESPACE_NAME_TOO_LONG"/>
 *     &lt;enumeration value="DUPLICATE_EXTERNAL_NAMESPACE_KEY"/>
 *     &lt;enumeration value="EXTERNAL_NAMESPACE_NOT_FOUND"/>
 *     &lt;enumeration value="EXTERNAL_ID_MAPPING_NOT_FOUND"/>
 *     &lt;enumeration value="DUPLICATE_EXTERNAL_ID_MAPPING"/>
 *     &lt;enumeration value="TEMPLATE_NOT_FOUND"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "errorCode")
@XmlEnum
public enum ErrorCode {

    SERVER_REGISTRATION_ERROR,
    SERVER_PERFORMING_UPDATE,
    NO_ANALYSIS_RUNNING,
    ANALYSIS_ALREADY_RUNNING,
    INVALID_SOURCE_LOCATION_FOR_SCAN,
    PROJECT_COULD_NOT_BE_LOCKED,
    LICENSE_NAME_TOO_LONG,
    LICENSE_TYPE_STANDARD_CANT_CHANGE_NAME,
    TAG_NOT_FOUND,
    OBLIGATION_IS_REFERENCED,
    OBLIGATION_NOT_ASSIGNED,
    DUPLICATE_LICENSE_NAME,
    LICENSE_NOT_FOUND,
    LICENSE_IN_USE,
    CAN_NOT_RESET_CUSTOM_LICENSE,
    DUPLICATE_OBLIGATION_CATEGORY,
    OBLIGATION_CATEGORY_NOT_FOUND,
    OBLIGATION_CATEGORY_IN_USE,
    OBLIGATION_CATEGORY_CAN_NOT_BE_DELETED,
    DUPLICATE_OBLIGATION_NAME,
    DUPLICATE_OBLIGATION_ASSIGNMENT,
    INVALID_OBLIGATION_NAME,
    OBLIGATION_NOT_FOUND,
    OBLIGATION_IN_USE_BY_PROJECTS,
    OBLIGATION_IN_USE_BY_LICENSES,
    RAPID_ID_CONFIGURATION_NOT_FOUND,
    RAPID_ID_CONFIGURATION_DUPLICATE_NAME,
    RAPID_ID_CONFIGURATION_DUPLICATE_ASSOCIATION,
    RAPID_ID_OPERATION_TYPE_DUPLICATE,
    LEARNED_IDENTIFICATION_NOT_FOUND,
    USER_NOT_ASSIGNED_TO_PROJECT,
    UNKNOWN_ANALYSIS_DATABASE_OPTION,
    STRING_SEARCH_PATTERN_UPDATE_OF_STANDARD_PATTERN_NOT_ALLOWED,
    CUSTOM_COMPONENT_IN_USE,
    CUSTOM_COMPONENT_HAS_NO_SOURCE,
    DUPLICATE_TEMPLATE_TITLE,
    REPORT_TEMPLATE_NOT_FOUND,
    DUPLICATE_PROJECT_NAME,
    PROJECT_ANALYSIS_LOCAL_SOURCE_NOT_SUPPORTED,
    OPTIONS_SETTING_NOT_ALLOWED,
    OPTIONS_CANNOT_BE_FORCED_FOR_LOCAL_SEARCH_SETTINGS,
    DUPLICATE_STRING_SEARCH_PATTERN_NAME,
    DUPLICATE_FILE_DISCOVERY_PATTERN_NAME,
    LINKING_PROJECTS_FORCES_CLONING_OF_WORK_RESULTS,
    PROJECT_NOT_YET_ANALYZED,
    DUPLICATE_USER_ASSIGNMENT,
    PROJECT_NAME_TOO_LONG,
    INVALID_PROJECT_NAME,
    PROJECT_NOT_FOUND,
    PROJECT_SYNCID_INVALID,
    LINKING_GLOBALLY_DISABLED,
    PROJECT_IN_USE,
    STRING_SEARCH_PATTERN_NAME_TOO_LONG,
    ROLE_NOT_FOUND,
    MINIMUM_ONE_ADMIN_USER,
    REMOVE_SELF_AS_ADMIN_USER,
    DUPLICATE_EMAIL_ADDRESS,
    EMAIL_TOO_LONG,
    FIRST_NAME_TOO_LONG,
    LAST_NAME_TOO_LONG,
    EXTERNAL_AUTHENTICATION_ID_TOO_LONG,
    EXTERNAL_AUTHENTICATION_ID_DUPLICATE,
    INVALID_EMAIL_ADDRESS,
    USER_NOT_FOUND,
    PASSWORD_TOO_SHORT,
    PASSWORD_TOO_LONG,
    STRING_SEARCH_DISCOVERY_NOT_FOUND,
    STRING_SEARCH_REQUIRES_UPLOADED_SOURCE,
    USAGE_LEVEL_INVALID_FOR_GIVEN_ID,
    CANNOT_COPY_ID_PROJECT_SYNCHRONIZED,
    CODE_TREE_PATH_NOT_FOUND,
    CODE_TREE_GUARANTEED_EMPTY_RESULT,
    NO_FILE_CONTENT,
    CODE_TREE_PARENT_PATH_NOT_FOUND,
    DUPLICATE_COMPONENT_NAME,
    COMPONENT_NAME_TOO_LONG,
    INVALID_COMPONENT_NAME,
    COMPONENT_NOT_FOUND,
    COMPONENT_VERSION_NOT_FOUND,
    OPTION_IS_FORCED,
    FILE_DISCOVERY_PATTERN_NOT_FOUND,
    STRING_SEARCH_PATTERN_NOT_FOUND,
    UNEXPECTED_EXCEPTION_ERROR,
    UNKNOWN_REPORT_SECTION_ERROR,
    PROTEX_FILE_SOURCE_NOT_AVAILABLE,
    NOT_A_FILE_PATH,
    ARGUMENT_VALUE_INVALID,
    METHOD_NOT_YET_IMPLEMENTED,
    ARGUMENT_NOT_YET_IMPLEMENTED,
    ARGUMENT_VALUE_NOT_YET_IMPLEMENTED,
    INVALID_CREDENTIALS,
    INSUFFICIENT_PERMISSION,
    UNKNOWN_ERROR,
    BOM_REFRESH_NOT_FINISHED,
    BOM_COMPONENT_PROJECT_CANT_UPDATE,
    UPDATE_BOM_COMPONENT_VERSION_NAME_OF_COMPONENT_VERSION_PROHIBITED,
    TODO_CONVERT_EXCEPTION,
    UNEXPECTED_RETURN_VALUE_ERROR,
    OUT_OF_MEMORY_ERROR,
    NO_SESSION_ID,
    INVALID_SORT_KEY,
    CAN_NOT_OPEN_TEMP_FILE,
    CODEMATCH_SELF_IDENTIFICATION_MUST_MATCH_DECLARED_LICENSE,
    IDENTIFICATION_NOT_FOUND,
    IDENTIFICATION_LEARNING_CONFLICT,
    EXTERNAL_NAMESPACE_NAME_TOO_LONG,
    DUPLICATE_EXTERNAL_NAMESPACE_KEY,
    EXTERNAL_NAMESPACE_NOT_FOUND,
    EXTERNAL_ID_MAPPING_NOT_FOUND,
    DUPLICATE_EXTERNAL_ID_MAPPING,
    TEMPLATE_NOT_FOUND;

    public String value() {
        return name();
    }

    public static ErrorCode fromValue(String v) {
        return valueOf(v);
    }

}
